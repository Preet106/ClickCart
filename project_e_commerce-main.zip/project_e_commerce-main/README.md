# E-Commerce
### [Live Site](https://commerce-js.netlify.app/)

![eCommerce](https://i.ibb.co/mH9SNNq/Build-an-e-commerce-1.png)

## Stay up to date with new projects
New major projects coming soon, subscribe to the mailing list to stay up to date https://javascriptmastery.eo.page/mailing-list.

## Introduction
This is a code repository for the corresponding video tutorial. 

In this video, we're going to build a fully functional eCommerce application using commerce.js. 

While building it you're going to learn many advanced React & JavaScript topics, as well as how to use Stripe for card transactions. On top of that, at the end of the video, you will have this unique and complex webshop app that you will be able to add to your portfolio. And trust me, e-commerce applications are impressive. 
